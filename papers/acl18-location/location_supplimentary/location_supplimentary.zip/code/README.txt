Each folder contains part of our experiments.
classifier holds our main classification models,
dependency and dataset are used for data preparation and feature extraction as well as sentence normalization.