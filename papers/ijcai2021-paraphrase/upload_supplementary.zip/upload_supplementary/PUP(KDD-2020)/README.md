As mentioned in the paper, the authors of "Unsupervised Paraphrasing via Deep Reinforcement Learning"(Their method is called "PUP") provided us their test set on Quora. However, in their test set, the BLEU score of the source sentence and reference is too large (we call it BLEU(src, ref) later).

With the following command, we can calculate the BLEU(src, ref) for the test set in PUP and UPSA:
```
bash cal.sh test_PUP.txt
bash cal.sh test_UPSA.txt
```
The result is 69.75 for PUP, and 25.63 for UPSA. This means that we can get  a 52.78 i-BLEU score by simply copying the source sentences with the PUP's test set. However, if we are using a normal test set (such as one provided by UPSA), this method can only get an i-BLEU score of 13.07.

What's more, if we look at the test set of PUP from the bottom up, we will find that most of the source sentences and references are exactly the same, but these identical parallel test pairs do not appear in the original parallel dataset provided by Quora. We think this is also the reason why BLEU(src, ref) is so high in their test set.

We sent an email to the authors to explain this problem after receiving their test set on Quora, hoping to get the result of their method on a normal test set, but we did not receive a reply. Therefore, we are not going to take their method as one of our baselines.
