cut -f1 $1 > source
cut -f2 $1 > reference

python evaluate.py --reference_path reference --generated_path source

rm -rf source reference

