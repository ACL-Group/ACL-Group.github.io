"""Define constant values used thoughout the project."""

START_OF_SENTENCE_TOKEN = "<S>"
END_OF_SENTENCE_TOKEN = "</S>"
UNKNOWN_TOKEN = "<UNK>"

UNKNOWN_ID=1
START_OF_SENTENCE_ID = 2
END_OF_SENTENCE_ID = 0
